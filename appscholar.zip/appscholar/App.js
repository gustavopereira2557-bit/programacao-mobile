import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
  FlatList,
  Platform
} from 'react-native';

const TIPOS = [
  { chave: 'Aluno', plural: 'Alunos', campo2: 'Curso', campo3: 'E-mail' },
  { chave: 'Boletim', plural: 'Boletins', campo2: 'Disciplina', campo3: 'Nota' },
  { chave: 'Professor', plural: 'Professores', campo2: 'Disciplina', campo3: 'E-mail' },
  { chave: 'Curso', plural: 'Cursos', campo2: 'Carga Horária', campo3: 'Coordenador' },
  { chave: 'Disciplina', plural: 'Disciplinas', campo2: 'Curso', campo3: 'Carga Horária' },
  { chave: 'Responsável', plural: 'Responsáveis', campo2: 'Aluno Vinculado', campo3: 'Telefone' },
  { chave: 'Matrícula', plural: 'Matrículas', campo2: 'Curso/Disciplina', campo3: 'Data (dd/mm/aaaa)' },
  { chave: 'Turma', plural: 'Turmas', campo2: 'Curso', campo3: 'Período' },
  { chave: 'Avaliação', plural: 'Avaliações', campo2: 'Disciplina', campo3: 'Data (dd/mm/aaaa)' },
  { chave: 'Coordenador', plural: 'Coordenadores', campo2: 'Curso', campo3: 'E-mail' }
];

function getConfigTipo(chave) {
  return TIPOS.find((t) => t.chave === chave);
}

export default function App() {
  const [tela, setTela] = useState('home');
  const [tipoSelecionado, setTipoSelecionado] = useState(null);
  const [editandoId, setEditandoId] = useState(null);
  const [registros, setRegistros] = useState([]);
  const [nome, setNome] = useState('');
  const [campo2, setCampo2] = useState('');
  const [campo3, setCampo3] = useState('');

  function exibirMensagem(titulo, msg) {
    if (Platform.OS === 'web') {
      window.alert(titulo + '\n' + msg);
    } else {
      Alert.alert(titulo, msg);
    }
  }

  function abrirCadastro(tipo) {
    setTipoSelecionado(tipo);
    limparFormulario();
    setTela('cadastro');
  }

  function abrirConsulta(tipo) {
    setTipoSelecionado(tipo);
    setTela('consulta');
  }

  function voltarHome() {
    setTipoSelecionado(null);
    limparFormulario();
    setTela('home');
  }

  function limparFormulario() {
    setNome('');
    setCampo2('');
    setCampo3('');
    setEditandoId(null);
  }

  function salvarRegistro() {
    if (!nome.trim() || !campo2.trim() || !campo3.trim()) {
      exibirMensagem('APP Scholar', 'Preencha todos os campos.');
      return;
    }

    if (editandoId) {
      setRegistros(
        registros.map((item) =>
          item.id === editandoId ? { ...item, nome, campo2, campo3 } : item
        )
      );
      exibirMensagem('APP Scholar', `${tipoSelecionado} atualizado com sucesso!`);
    } else {
      const novoRegistro = {
        id: Date.now().toString(),
        tipo: tipoSelecionado,
        nome,
        campo2,
        campo3
      };
      setRegistros([...registros, novoRegistro]);
      exibirMensagem('APP Scholar', `${tipoSelecionado} cadastrado com sucesso!`);
    }

    limparFormulario();
    setTela('consulta');
  }

  function editarRegistro(item) {
    setNome(item.nome);
    setCampo2(item.campo2);
    setCampo3(item.campo3);
    setEditandoId(item.id);
    setTela('cadastro');
  }

  function excluirRegistro(id) {
    Alert.alert('APP Scholar', 'Deseja realmente excluir este registro?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Excluir',
        style: 'destructive',
        onPress: () => setRegistros(registros.filter((item) => item.id !== id))
      }
    ]);
  }

  const registrosFiltrados = registros.filter((item) => item.tipo === tipoSelecionado);

  if (tela === 'home') {
    return (
      <ScrollView contentContainerStyle={styles.container}>
        <Image source={require('./assets/logo.png')} style={styles.logo} />
        <Text style={styles.titulo}>APP Scholar</Text>
        <Text style={styles.subtitulo}>Sistema Acadêmico Mobile</Text>

        {TIPOS.map((tipo) => (
          <View style={styles.containerBotoes} key={tipo.chave}>
            <TouchableOpacity style={styles.botao} onPress={() => abrirConsulta(tipo.chave)}>
              <Text style={styles.textoBotao}>Consultar {tipo.plural}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.botao} onPress={() => abrirCadastro(tipo.chave)}>
              <Text style={styles.textoBotao}>Cadastrar {tipo.chave}</Text>
            </TouchableOpacity>
          </View>
        ))}

        <View style={styles.containerBotoes}>
          <TouchableOpacity
            style={[styles.botao, { width: '100%' }]}
            onPress={() => exibirMensagem('Sobre', 'APP Scholar - José Vieira Macedo - ETEC')}
          >
            <Text style={styles.textoBotao}>Sobre</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    );
  }

  if (tela === 'cadastro') {
    const rotulos = getConfigTipo(tipoSelecionado);
    return (
      <ScrollView contentContainerStyle={styles.containerForm}>
        <Text style={styles.titulo}>
          {editandoId ? 'Editar' : 'Cadastrar'} {tipoSelecionado}
        </Text>

        <TextInput style={styles.input} placeholder="Nome" value={nome} onChangeText={setNome} />
        <TextInput
          style={styles.input}
          placeholder={rotulos.campo2}
          value={campo2}
          onChangeText={setCampo2}
        />
        <TextInput
          style={styles.input}
          placeholder={rotulos.campo3}
          value={campo3}
          onChangeText={setCampo3}
        />

        <TouchableOpacity style={[styles.botao, { width: '80%' }]} onPress={salvarRegistro}>
          <Text style={styles.textoBotao}>Salvar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.botaoSecundario} onPress={voltarHome}>
          <Text style={styles.textoBotaoSecundario}>Voltar para o início</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  if (tela === 'consulta') {
    const rotulos = getConfigTipo(tipoSelecionado);
    return (
      <View style={styles.containerForm}>
        <Text style={styles.titulo}>{rotulos.plural} Cadastrados</Text>

        {registrosFiltrados.length === 0 ? (
          <Text style={styles.subtitulo}>Nenhum registro encontrado.</Text>
        ) : (
          <FlatList
            style={{ width: '100%' }}
            data={registrosFiltrados}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.card}>
                <Text style={styles.cardNome}>{item.nome}</Text>
                <Text style={styles.cardInfo}>{rotulos.campo2}: {item.campo2}</Text>
                <Text style={styles.cardInfo}>{rotulos.campo3}: {item.campo3}</Text>
                <View style={styles.cardBotoes}>
                  <TouchableOpacity style={styles.botaoEditar} onPress={() => editarRegistro(item)}>
                    <Text style={styles.textoBotaoSecundario}>Editar</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.botaoExcluir} onPress={() => excluirRegistro(item.id)}>
                    <Text style={styles.textoBotao}>Excluir</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />
        )}

        <TouchableOpacity style={styles.botaoSecundario} onPress={voltarHome}>
          <Text style={styles.textoBotaoSecundario}>Voltar para o início</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return null;
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: 'center',
    paddingVertical: 30,
    backgroundColor: '#FFFFFF'
  },
  containerForm: {
    flexGrow: 1,
    alignItems: 'center',
    paddingTop: 50,
    paddingHorizontal: 20,
    backgroundColor: '#FFFFFF'
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 20
  },
  titulo: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#1565C0',
    textAlign: 'center',
    marginBottom: 6
  },
  subtitulo: {
    fontSize: 16,
    marginBottom: 30,
    color: '#666',
    textAlign: 'center'
  },
  containerBotoes: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    width: '100%',
    marginBottom: 15
  },
  botao: {
    width: '48%',
    backgroundColor: '#1976D2',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center'
  },
  textoBotao: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FFFFFF'
  },
  botaoSecundario: {
    width: '80%',
    borderWidth: 1,
    borderColor: '#1976D2',
    padding: 15,
    borderRadius: 10,
    marginTop: 10,
    marginBottom: 30,
    alignItems: 'center'
  },
  textoBotaoSecundario: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1976D2'
  },
  input: {
    width: '100%',
    borderWidth: 1,
    borderColor: '#CCCCCC',
    borderRadius: 10,
    padding: 12,
    marginBottom: 15,
    fontSize: 16
  },
  card: {
    width: '100%',
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    padding: 15,
    marginBottom: 12
  },
  cardNome: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1565C0',
    marginBottom: 4
  },
  cardInfo: {
    fontSize: 14,
    color: '#444'
  },
  cardBotoes: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 10
  },
  botaoEditar: {
    borderWidth: 1,
    borderColor: '#1976D2',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 14,
    marginRight: 10
  },
  botaoExcluir: {
    backgroundColor: '#D32F2F',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 14
  }
});